var chartCommonData = {
    title: 'Unemployment rate per cent 2024',
    data: [
        {label: 'Czechia', value: 3},
        {label: 'Greece', value: 'TODO - find value and round to integer'},
        {label: 'Poland', value: 3},
        {label: 'Hungary', value: 'TODO - find value and round to integer'},
        {label: 'Spain', value: 11},
    ],
}

var COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', 'TODO - add magenta as #RRGGBB']

// TODO export chartCommonData and COLORS